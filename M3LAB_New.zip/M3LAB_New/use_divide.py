# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 11:33:48 2019

@author: newc0495
"""

import divide as d

def main():
    option = input("Enter '1' to divide, '2' to integer divide: ")
    
    if option == '1':
        num1 = input("Enter first number: ")
        num2 = input("Enter second number: ")        
        print("The quotient of", num1, "and", num2, "is", d.divide(num1, num2))
    elif option == '2':
        num1 = input("Enter first number: ")
        num2 = input("Enter second number: ")
        print("The quotient of", num1, "and", num2, "is", d.intDivide(num1, num2))
    else:
        print("Enter a valid option: \n")
        main()

main() 