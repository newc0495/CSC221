# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 11:33:48 2019

@author: newc0495
"""

def add(x, y):
    """return the sum of x and y
    
    >>> add(1, 1)
    2
    >>> add(2, 3)
    5
    >>> add(1.0, 2.0)
    3.0
    >>> add(1, 1.2)
    2.2
    >>> add(1, 1.0)
    2.0

    """
    return x + y

if __name__ == "__main__":
    import doctest
    print("running doctests")
    doctest.testmod()
    print("tests complete")