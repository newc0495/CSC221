# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 11:33:47 2019

@author: newc0495
"""

import square as sq

num = int(input("Enter a number: "))
print("That number squared is", sq.square(num))