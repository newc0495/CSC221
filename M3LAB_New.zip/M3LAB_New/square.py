# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 11:33:46 2019

@author: newc0495
"""

def square(x):
    """return square of x
    
    >>> square(2)
    4
    >>> square(-2)
    4

    """
    return x * x
    
if __name__ == "__main__":
    import doctest
    print("running doctests")
    doctest.testmod()
    print("tests complete")