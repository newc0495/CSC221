# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 11:33:48 2019

@author: newc0495
"""

def divide(x, y):
    """divides x by y (will deliver decimal answers if decimal input)
    
    >>> divide(1, 1)
    1.0
    >>> divide(9, 4)
    2.25
    >>> divide(2.0, 1)
    2.0
    
    """
    return x / y


def intDivide(x, y):
    """integer divides x by y (will truncate any decimals input)
    
    >>> intDivide(1, 1)
    1
    >>> intDivide(8, 4)
    2
    >>> intDivide(2.0, 1.0)
    2.0
    >>> intDivide(2.2, 1)
    2.0
    
    """
    return x // y

if __name__ == "__main__":
    import doctest
    print("running doctests")
    doctest.testmod()
    print("tests complete")