# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 11:33:48 2019

@author: newc0495
"""

import add as a

num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
print("The sum of", num1, "and", num2, "is", a.add(num1, num2))