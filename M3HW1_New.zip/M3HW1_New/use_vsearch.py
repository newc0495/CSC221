# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 11:14:53 2019

@author: newc0495
"""

from vsearch import search4vowels as vow

word = input("Enter a word to search through: ")
answer = vow(word)
print(answer)