# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 11:14:00 2019

@author: newc0495
"""

def double(arg):
    print('Before: ', arg)
    arg = arg * 2
    print('After: ', arg)
    
    
def change(arg: list):
    print('Before: ', arg)
    arg.append('More data')
    print('After: ', arg)