# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 11:12:56 2019

@author: newc0495
"""

from setuptools import setup

setup(
      name='vsearch',
      version='1.0',
      description='The Head First Python Search Tools',
      author='HF Python 2e',
      author_email='hfpy2e@gmail.com',
      url='headfirstlabs.com',
      py_modules=['vsearch'],
)