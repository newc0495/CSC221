# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""



def main():
    print("Option '1' to find vowels.")
    print("Option '2' to find specific letters.")
    print("Option '3' to exit.")
    
    choice = input("Enter your option: ")
    if choice == '1':
        word = input("Please enter a word to search for vowels: ")
        answer = has_which_vowels(word)
        print(answer)
        
    elif choice == '2':
        print('2')
        word = input("Please enter a word to search through: ")
        llist = input("Please enter some letters to look for: ")
        answer = has_which_letters(word, llist)
        print(answer)
        
    elif choice == '3':
        print("Goodbye!")
        
    else:
        print("Please enter a valid option: ")
        main()

def has_which_vowels(word):
    vowels = ['a', 'e', 'i', 'o', 'u']
    found = []
    for letter in word:
        if letter in vowels:
            if letter not in found:
                found.append(letter)
    return found

def has_which_letters(word, llist):
    found = []
    for letter in word:
        if letter in llist:
            if letter not in found:
                found.append(letter)
    return found
    
main()