# -*- coding: utf-8 -*-
# M1HW1
# CSC 221
# Christian New
# 01/23/19
"""
Author: newc0495
various calls to programs
"""
def main():
    print("Enter '1' for 'bob'")
    print("Enter '2' for 'odd'")
    print("Enter '3' for 'odd2'")

    choice = input("Enter your option: ")
    if choice == '1':
        import bob
    elif choice == '2':
        import odd
    elif choice == '3':
        import odd2
    else:
        print("Please enter a valid option: ")
        main()

main()
