# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

STATE_TAX = .04
COUNTY_TAX = .02

prodName = input("Enter the name of the product: ")
pricePerUnit = float(input("Enter the price per unit: "))
count = int(input("Enter the unit count: "))

subtotal = pricePerUnit * count
finalCost = subtotal + (subtotal * STATE_TAX) + (subtotal * COUNTY_TAX)

print(subtotal)
print(finalCost)