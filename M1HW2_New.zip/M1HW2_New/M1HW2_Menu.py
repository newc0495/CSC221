# -*- coding: utf-8 -*-
# M1HW1
# CSC 221
# Christian New
# 01/23/19
"""
Author: newc0495
various calls to programs
"""
def main():
    print("Enter '1' for 'POS'")
    print("Enter '2' for 'fishing'")
    print("Enter '3' for 'riverriddle'")

    choice = input("Enter your option: ")
    if choice == '1':
        import POS
    elif choice == '2':
        import fishing
    elif choice == '3':
        import riverriddle
    else:
        print("Please enter a valid option: ")
        main()

main()
