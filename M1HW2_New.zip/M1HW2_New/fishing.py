# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
days = ["Friday","Saturday","Sunday"]
total = 0 
for day in days:
    count = int(input("How many fish did you catch " + day + "?: "))    
    total += count
avg = total / 3
print("You caught", total, "fish this weekend.")
print("Your average catch per day is", avg, ".")    