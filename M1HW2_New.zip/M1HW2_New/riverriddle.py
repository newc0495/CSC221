# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
def main():
    fox = True
    chicken = True
    grain = True  

# start
    update(fox,chicken,grain)

# step 1
    print("Step 1:")
    print("Take the chicken to the far side.\n")    
    chicken = False
    update(fox,chicken,grain)

# step 2
    print("Step 2:")
    print("Take the grain to the far side.")
    print("Bring the chicken back with you to the near side.\n")
    grain = False
    chicken = True
    update(fox,chicken,grain)
    
# step 3
    print("Step 3:")
    print("Take the fox to the far side.\n")
    fox = False
    update(fox,chicken,grain)
    
# step 4
    print("Step 4:")
    print("Take the chicken to the far side.\n")
    chicken = False
    update(fox,chicken,grain)

def update(fox, chicken, grain):
    if fox == True:
        print("Fox is on the near side")
    else:
        print("Fox is on the far side")
    if chicken == True:
        print("Chicken is on the near side")
    else:
        print("Chicken is on the far side")
    if grain == True:
        print("Grain is on the near side")
    else:
        print("Grain is on the far side")
    print("")

main()        