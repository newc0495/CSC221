# -*- coding: utf-8 -*-
"""
Created on Wed Feb  6 12:22:12 2019

@author: newc0495
"""

vowels = set('aeiou')
word = input("Provide a word to search for vowels: ")
found = vowels.intersection(set(word))
for vowel in found:
    print(vowel)