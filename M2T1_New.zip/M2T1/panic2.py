# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 11:13:46 2019

@author: newc0495
"""

phrase = "Don't panic!"
plist = list(phrase)
print(phrase)
print(plist)

new_phrase = ''.join(plist[1:3])
new_phrase = new_phrase + ''.join([plist[5], plist[4], plist[7], plist[6]])

print(plist)
print(new_phrase)