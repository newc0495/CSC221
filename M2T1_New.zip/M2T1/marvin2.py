# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 11:13:47 2019

@author: newc0495
"""

paranoid_android = "Marvin, the Paranoid Android"
letters = list(paranoid_android)
for char in letters[:6]:
    print('\t', char)
print()
for char in letters[-7:]:
    print('\t'*2, char)
print()
for char in letters[12:20]:
    print('\t'*3, char)