# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 11:13:24 2019

@author: newc0495
"""

vowels = ['a', 'e', 'i', 'o', 'u']
word = "Milliways"
for letter in word:
    if letter in vowels:
        print(letter)