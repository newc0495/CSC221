# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 11:13:46 2019

@author: newc0495
"""

paranoid_android = "Marvin"
letters = list(paranoid_android)
for char in letters:
    print('\t', char)